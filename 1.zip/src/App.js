import React from 'react';
import './App.css';
import BaiTapGioHang from './BaiTapGioHang/BaiTapGioHang';
function App() {
  return (
    <div>
      {/* <Demo/>
      <DemoF/> */}
      {/* <BaiTapLayout/> */}
      {/* <DataBinding/> */}
      {/* <HandleEvent/> */}
      {/* <StateDemo/> */}
      {/* <BaiTapState/> */}
      {/* <RenderWithMap/> */}
      {/* <RenderFilm/> */}
      {/* <Header title="Student " logo="./img/logo.jpg"/> */}
      {/* <Header/> */}
      {/* <DanhSachPhim mangPhim = {data} /> */}
      {/* <BaiTapQuanLyXeRedux/> */}
      {/* <BaiTapThuKinh/> */}
      <BaiTapGioHang/>
    </div>
  );
}

export default App;
