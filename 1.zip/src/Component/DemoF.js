import React from 'react'

export default function DemoF() {
    //không chứa thuộc tính và phương thức do không phải class
    //có thể chứa biến và hàm
    return (
        <div>
            <h1>Hello 420</h1>
        </div>
    )
}
